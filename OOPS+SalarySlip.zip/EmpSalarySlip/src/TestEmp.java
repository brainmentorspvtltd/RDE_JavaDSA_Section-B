public class TestEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee obj = new Employee(101,"Ram shaRMA KuMar",45000);
		System.out.println(obj.showEmp());
	}

}
