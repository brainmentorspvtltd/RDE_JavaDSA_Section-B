import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionDemo {

	public static void main(String[] args) {
		
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter first number : ");
			int num_1 = scanner.nextInt();
			System.out.println("Enter second number : ");
			int num_2 = scanner.nextInt();
			int res = num_1 / num_2;
			System.out.println("Result is : "+res);
			scanner.close();
			
			int arr[] = new int[10];
			arr[11] = 200;
			
		}
		
		catch (InputMismatchException e) {
			// TODO: handle exception
			System.out.println("Invalid Input...");
		}
		catch(ArithmeticException e) {
			System.out.println("Cannot divide by zero...");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Array size is not available...");
		}
		
		catch(Exception e) {
			System.out.println("Some error...");
		}
		
	}

}
