class Basics {

	public static strictfp void main(String[] args) {
		int x = 10;
		int y = 12;
		int z = x + y;
		System.out.println("Sum is "+z);
		float x1 = 10.6f;
//		System.out.println(x1);
		double x2 = 10.45;
		System.out.println(x1 + ", " + x2);
	}

}
