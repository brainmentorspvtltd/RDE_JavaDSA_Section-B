class XYZ {
   public static void main(String arr[])
  {
     //System.out.println("Hello World");
    // System.out.println(arr[0] + "," + arr[1]);

    int x = Integer.parseInt(arr[0]);
    int y = Integer.parseInt(arr[1]);
    System.out.println(x+y);
  }
}





